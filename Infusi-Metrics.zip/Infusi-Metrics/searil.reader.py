
import serial

PORT = "rfc2217://localhost:4000"
BAUD_RATE = 9600


def parse_line(line):
    parts = line.strip().split(",")

    try:
        if len(parts) == 3 and parts[0] == "DATA":
            return {
                "type": "DATA",
                "elapsed_ms": int(parts[1]),
                "level": float(parts[2]),
            }

        if len(parts) >= 7 and parts[0] == "EVENT":
            return {
                "type": "EVENT",
                "elapsed_ms": int(parts[1]),
                "level": float(parts[2]),
                "event": parts[3],
                "rate": float(parts[4]),
                "latitude": float(parts[5]),
                "longitude": float(parts[6]),
            }

        if len(parts) == 3 and parts[0] == "ENV":
            return {
                "type": "ENV",
                "temperature": float(parts[1]),
                "humidity": float(parts[2]),
            }

        if len(parts) == 2 and parts[0] == "DIST":
            return {
                "type": "DIST",
                "distance_cm": float(parts[1]),
            }

        if len(parts) == 2 and parts[0] == "NURSE":
            return {
                "type": "NURSE",
                "state": int(parts[1]),
            }

    except ValueError:
        print("Could not parse:", line)

    return None


try:
    with serial.serial_for_url(
        PORT,
        baudrate=BAUD_RATE,
        timeout=2,
    ) as connection:

        print("Connected to Wokwi!")
        print("Waiting for Arduino messages. Press Ctrl+C to stop.\n")

        while True:
            raw_line = connection.readline()

            if not raw_line:
                continue

            line = raw_line.decode(
                "utf-8", errors="replace"
            ).strip()

            record = parse_line(line)

            if record:
                kind = record["type"]

                if kind == "DATA":
                    print(
                        f"IV Level: {record['level']:.1f}% "
                        f"| Time: {record['elapsed_ms']} ms"
                    )

                elif kind == "EVENT":
                    print(
                        f"EVENT: {record['event']} "
                        f"| Level: {record['level']:.1f}% "
                        f"| Rate: {record['rate']:.1f} %/min"
                    )

                elif kind == "ENV":
                    print(
                        f"Temperature: {record['temperature']:.1f} °C "
                        f"| Humidity: {record['humidity']:.1f}%"
                    )

                elif kind == "DIST":
                    print(
                        f"Ultrasonic Distance: "
                        f"{record['distance_cm']:.1f} cm"
                    )

                elif kind == "NURSE":
                    print(f"Nurse state: {record['state']}")

            else:
                print(line)

except KeyboardInterrupt:
    print("\nReader stopped.")

except serial.SerialException as error:
    print("Serial connection error:", error)
