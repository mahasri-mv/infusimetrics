import pandas as pd
import streamlit as st
from sklearn.linear_model import LinearRegression


def predict_next_level(level_history):
    """Predict the next simulated level from recent readings."""
    levels = []

    for item in level_history:
        try:
            if isinstance(item, dict):
                value = item.get("level")
            elif isinstance(item, (tuple, list)):
                value = item[-1]
            else:
                value = item

            value = float(value)
            if 0 <= value <= 100:
                levels.append(value)
        except (TypeError, ValueError):
            continue

    levels = levels[-30:]

    if len(levels) < 5:
        return None, "Collect at least 5 valid readings first."

    X = pd.DataFrame({"reading_number": range(len(levels))})
    y = pd.Series(levels)

    model = LinearRegression()
    model.fit(X, y)

    next_level = float(model.predict(
        pd.DataFrame({"reading_number": [len(levels)]})
    )[0])

    next_level = max(0.0, min(100.0, next_level))
    return next_level, "Experimental estimate from recent simulated readings."


def answer_question(question, current_level, status, events, extra=None):
    """Simple intent-based NLP question answering.

    `extra` is an optional dict with: rate, temperature, humidity,
    distance, nurse_call. Old calls without it still work.
    """
    q = question.lower().strip()
    extra = extra or {}

    # ----- new intents (checked first) -----
    if "nurse" in q or "assist" in q:
        state = extra.get("nurse_call", 0)
        if state == 1:
            return "A nurse call is active. The patient is waiting for assistance."
        if state == 2:
            return "The nurse call is UNANSWERED and has been escalated to backup staff."
        return "There is no active nurse call."

    if "temperature" in q or "humidity" in q:
        temperature = extra.get("temperature")
        humidity = extra.get("humidity")
        if temperature is None or humidity is None:
            return "No temperature or humidity reading is available yet."
        return (
            f"The room temperature is {temperature:.1f} °C and the humidity "
            f"is {humidity:.1f}%."
        )

    if "distance" in q or "ultrasonic" in q:
        distance = extra.get("distance")
        if distance is None:
            return "No ultrasonic distance reading is available yet."
        return f"The ultrasonic sensor reads {distance:.1f} cm."

    if any(p in q for p in ["how long", "time left", "time remaining",
                            "remaining", "run out", "when will"]):
        rate = extra.get("rate") or 0.0
        if current_level is None:
            return "No IV level reading is available yet."
        if rate > 0.3:
            minutes_empty = current_level / rate
            minutes_low = max(0.0, (current_level - 20) / rate)
            return (
                f"At the current drain rate of {rate:.1f} %/min, about "
                f"{minutes_empty:.1f} minutes remain until empty and about "
                f"{minutes_low:.1f} minutes until the 20% LOW alert."
            )
        return "The bottle is not draining at a measurable rate, so I cannot predict the time left."

    # ----- original intents -----
    if any(word in q for word in ["level", "percentage", "how much", "fluid"]):
        if current_level is None:
            return "No IV level reading is available yet."
        return f"The latest simulated IV fluid level is {current_level:.1f}%."

    if any(word in q for word in ["low", "alert", "empty"]):
        if "low: yes" in status.lower():
            return "The latest Arduino status reports a LOW-level alert."
        if current_level is not None and current_level <= 20:
            return f"The level is {current_level:.1f}%. It is at or below the demo threshold of 20%."
        return "No low-level alert is currently reported."

    if any(word in q for word in ["clamp", "blocked", "flow"]):
        if "clamped: yes" in status.lower():
            return "The latest Arduino status reports that the line is clamped."
        return "The latest status does not report a clamped line."

    if any(word in q for word in ["event", "refill", "last"]):
        if events:
            return f"The most recent recorded event is: {events[-1]}"
        return "No events have been received yet."

    if any(word in q for word in ["status", "condition", "working"]):
        return status or "No Arduino status has been received yet."

    return (
        "I can answer questions about the current level, time left, low alerts, "
        "clamp status, nurse calls, temperature, distance, recent events, "
        "and Arduino status."
    )
