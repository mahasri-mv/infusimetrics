import re
import time
import threading

import pandas as pd
import serial
import streamlit as st
from streamlit_autorefresh import st_autorefresh

from smart_features import predict_next_level, answer_question

# Must match Serial.begin(9600) in the Arduino sketch.
PORT = "rfc2217://localhost:4000"
BAUD_RATE = 9600
RETRY_SECONDS = 3

ML_EVENTS = {"EARLY_WARN", "LEAK_SUSPECTED", "BLOCK_SUSPECTED"}
SIM_NAMES = {0: "Off (real sensor)", 1: "Normal drain", 2: "Leak", 3: "Blockage"}
NURSE_MESSAGES = {
    0: "No active nurse call",
    1: "NURSE CALL ACTIVE",
    2: "UNANSWERED - ESCALATED",
}
RATE_RE = re.compile(r"rate:\s*(-?\d+(?:\.\d+)?)", re.IGNORECASE)
SIM_RE = re.compile(r"sim:\s*(\d)", re.IGNORECASE)


st.set_page_config(
    page_title="Smart IV Fluid Monitor",
    page_icon="💧",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        max-width: 1400px;
    }
    div[data-testid="stMetric"] {
        background: #172536;
        border: 1px solid #29445c;
        padding: 18px;
        border-radius: 14px;
    }
    div[data-testid="stMetricLabel"] {
        color: #b8cce0;
    }
</style>
""", unsafe_allow_html=True)


# --------------------------------------------------
# One shared serial connection for the whole server.
# The simulator's port 4000 accepts only ONE client, so the connection
# must not be recreated for every browser tab or page refresh.
# --------------------------------------------------
class SerialHub:
    def __init__(self):
        self.lock = threading.Lock()         # protects self.data
        self.write_lock = threading.Lock()   # protects self.connection
        self.connection = None
        self.thread = None
        self.data = {
            "level": None,
            "rate": 0.0,
            "low": False,
            "clamped": False,
            "status": "Connecting to Wokwi...",
            "temperature": None,
            "humidity": None,
            "distance": None,
            "nurse_call": 0,
            "nurse_message": NURSE_MESSAGES[0],
            "sim_mode": 0,
            "last_ml_event": "None yet",
            "history": [],
            "events": [],
            "alerts": [],
            "console": [],
        }

    # ---------- thread control ----------
    def ensure_running(self):
        if self.thread is None or not self.thread.is_alive():
            self.thread = threading.Thread(target=self._run, daemon=True)
            self.thread.start()

    def snapshot(self):
        with self.lock:
            snap = dict(self.data)
            for key in ("history", "events", "alerts", "console"):
                snap[key] = list(self.data[key])
        return snap

    # ---------- sending commands to the Arduino ----------
    def send(self, text):
        text = text.strip()
        if not text:
            return False
        with self.write_lock:
            conn = self.connection
            if conn is None:
                return False
            try:
                conn.write((text + "\n").encode("utf-8"))
                return True
            except Exception as error:
                print("Send error:", error)
                return False

    # ---------- reader thread ----------
    def _run(self):
        while True:
            try:
                with serial.serial_for_url(
                    PORT, baudrate=BAUD_RATE, timeout=2
                ) as conn:
                    with self.write_lock:
                        self.connection = conn
                    self._set("status", "Connected to Wokwi")

                    while True:
                        raw = conn.readline()
                        if not raw:
                            continue
                        line = raw.decode("utf-8", errors="replace").strip()
                        if line:
                            self._handle(line)

            except Exception as error:
                self._set("status", f"Serial error: {error}")
                print("Serial reader error:", error)

            finally:
                with self.write_lock:
                    self.connection = None

            time.sleep(RETRY_SECONDS)   # then try to reconnect

    def _set(self, key, value):
        with self.lock:
            self.data[key] = value

    def _add(self, key, item, keep):
        with self.lock:
            self.data[key].append(item)
            self.data[key] = self.data[key][-keep:]

    # ---------- parse one Arduino line ----------
    def _handle(self, line):
        parts = line.split(",")
        kind = parts[0]

        try:
            # DATA,elapsed_ms,level
            if kind == "DATA" and len(parts) == 3:
                elapsed = int(parts[1]) / 1000.0
                level = float(parts[2])
                with self.lock:
                    self.data["level"] = level
                    self.data["history"].append(
                        {"Time (s)": elapsed, "Level (%)": level}
                    )
                    self.data["history"] = self.data["history"][-100:]

            # ENV,temperature,humidity
            elif kind == "ENV" and len(parts) == 3:
                temperature = float(parts[1])
                humidity = float(parts[2])
                with self.lock:
                    self.data["temperature"] = temperature
                    self.data["humidity"] = humidity

            # DIST,distance_cm
            elif kind == "DIST" and len(parts) == 2:
                distance = float(parts[1])
                with self.lock:
                    self.data["distance"] = distance

            # NURSE,0 / NURSE,1 / NURSE,2
            elif kind == "NURSE" and len(parts) == 2:
                state = int(parts[1])
                with self.lock:
                    self.data["nurse_call"] = state
                    self.data["nurse_message"] = NURSE_MESSAGES.get(
                        state, f"Unknown nurse state {state}"
                    )

            # EVENT,elapsed_ms,level,event,rate,latitude,longitude
            elif kind == "EVENT" and len(parts) >= 7:
                event = parts[3]
                rate = float(parts[4])
                with self.lock:
                    self.data["rate"] = max(0.0, rate)
                    self.data["events"].append(line)
                    self.data["events"] = self.data["events"][-20:]
                    if event in ML_EVENTS:
                        self.data["last_ml_event"] = event

            # STATUS | Level: 41% | Rate: 0.0 %/min | Low: NO | Clamped: NO | Sim: 0
            elif line.startswith("STATUS"):
                lower = line.lower()
                with self.lock:
                    self.data["status"] = line
                    self.data["low"] = (
                        "low: yes" in lower or "low alert: yes" in lower
                    )
                    self.data["clamped"] = (
                        "clamped: yes" in lower or "auto-clamped" in lower
                    )
                    match = RATE_RE.search(line)
                    if match:
                        self.data["rate"] = max(0.0, float(match.group(1)))
                    match = SIM_RE.search(line)
                    if match:
                        self.data["sim_mode"] = int(match.group(1))

            # Readable alert sentences from the Arduino
            elif line.startswith("ALERT"):
                self._add("alerts", line, 20)

            # Everything else: command replies, help text, SD messages
            else:
                self._add("console", line, 40)

        except ValueError:
            self._add("console", f"Could not parse: {line}", 40)


@st.cache_resource
def get_hub():
    return SerialHub()


hub = get_hub()
hub.ensure_running()

# Refresh the displayed readings every 2 seconds.
st_autorefresh(interval=2000, key="iv_refresh")

data = hub.snapshot()


def send_command(command):
    if hub.send(command):
        st.session_state["cmd_result"] = ("ok", f"Sent: {command}")
    else:
        st.session_state["cmd_result"] = (
            "error",
            "Not connected to the simulator - start Wokwi first.",
        )


# --------------------------------------------------
# Dashboard
# --------------------------------------------------
st.title("💧 Smart IV Fluid Monitoring Dashboard")
st.caption("Live readings from the Wokwi Arduino Mega simulation")


# Row 1: IV monitoring
st.subheader("IV Fluid Monitoring")

a, b, c, d = st.columns(4)

a.metric(
    "IV Fluid Level",
    f"{data['level']:.1f}%" if data["level"] is not None else "--",
)
b.metric("Drain Rate", f"{data['rate']:.1f} %/min")
c.metric("Low Alert", "YES" if data["low"] else "NO")
d.metric("Clamp Status", "CLAMPED" if data["clamped"] else "OPEN")

m1, m2 = st.columns(2)
m1.metric("Arduino ML: Last Warning", data["last_ml_event"])
m2.metric(
    "Demo Simulation Mode",
    SIM_NAMES.get(data["sim_mode"], str(data["sim_mode"])),
)


# Row 2: Environmental and distance sensors
st.subheader("🌡️ Environmental and Distance Sensors")

e, f, g = st.columns(3)

e.metric(
    "Temperature",
    f"{data['temperature']:.1f} °C" if data["temperature"] is not None else "--",
)
f.metric(
    "Humidity",
    f"{data['humidity']:.1f} %" if data["humidity"] is not None else "--",
)
g.metric(
    "Ultrasonic Distance",
    f"{data['distance']:.1f} cm" if data["distance"] is not None else "--",
)


# Row 3: Nurse-call monitoring
st.subheader("🩺 Nurse Alert System")

nurse_state = data["nurse_call"]

if nurse_state == 1:
    st.error("🔔 NURSE CALL ACTIVE — Patient needs assistance.")
elif nurse_state == 2:
    st.error("🚨 NURSE CALL UNANSWERED — Escalated to backup staff.")
else:
    st.success("No active nurse call.")

st.caption(f"Nurse status: {data['nurse_message']}")


# --------------------------------------------------
# Send commands to the Arduino (so no second serial program is needed)
# --------------------------------------------------
st.subheader("🎛️ Send Command to Arduino")

quick_commands = [
    ("Acknowledge nurse call", "ack"),
    ("Simulate drain", "simulate drain"),
    ("Simulate leak", "simulate leak"),
    ("Simulate blockage", "simulate block"),
    ("Simulation off", "simulate off"),
    ("Refill bottle", "refill"),
]

button_columns = st.columns(len(quick_commands))
for column, (label, command) in zip(button_columns, quick_commands):
    if column.button(label, key=f"btn_{command}"):
        send_command(command)

with st.form("command_form", clear_on_submit=True):
    typed_command = st.text_input(
        "Or type a command",
        placeholder="e.g. status, how long is left, where is the patient",
    )
    submitted = st.form_submit_button("Send")

if submitted and typed_command.strip():
    send_command(typed_command)

result = st.session_state.get("cmd_result")
if result:
    if result[0] == "ok":
        st.success(result[1])
    else:
        st.error(result[1])

st.caption(
    "The nurse button, potentiometer, DHT22 and ultrasonic sensor are still "
    "changed by clicking them in the Wokwi simulator."
)


# --------------------------------------------------
# Existing ML feature
# --------------------------------------------------
st.subheader("🤖 ML: Next IV Level Estimate")

if len(data["history"]) >= 5:
    levels = [item["Level (%)"] for item in data["history"]]

    prediction, message = predict_next_level(levels)

    if prediction is not None:
        st.metric("Estimated Next Level", f"{prediction:.1f}%")
        st.caption(message)
    else:
        st.info(message)
else:
    st.info("Collect at least 5 readings to enable the ML estimate.")


# --------------------------------------------------
# Existing NLP feature (now also knows nurse, temperature, distance, time left)
# --------------------------------------------------
st.subheader("💬 Ask About Your IV Simulation")

question = st.text_input(
    "Ask a question",
    placeholder="e.g. What is the current level? How long is left? Is there a nurse call?",
    key="iv_question",
)

if question:
    answer = answer_question(
        question,
        data["level"],
        data["status"],
        data["events"],
        extra={
            "rate": data["rate"],
            "temperature": data["temperature"],
            "humidity": data["humidity"],
            "distance": data["distance"],
            "nurse_call": data["nurse_call"],
        },
    )
    st.info(answer)


# --------------------------------------------------
# Status, history, alerts, events
# --------------------------------------------------
st.subheader("Arduino Status")
st.write(data["status"])

st.subheader("IV Level History")

if data["history"]:
    history_df = pd.DataFrame(data["history"])
    st.line_chart(history_df, x="Time (s)", y="Level (%)")
else:
    st.info("Waiting for IV readings from Wokwi...")

st.subheader("Latest Alerts")

if data["alerts"]:
    for alert in reversed(data["alerts"][-8:]):
        st.text(alert)
else:
    st.write("No alerts received yet.")

st.subheader("Recent Events")

if data["events"]:
    for event in reversed(data["events"]):
        st.text(event)
else:
    st.write("No events received yet.")

with st.expander("Arduino messages (command replies)"):
    if data["console"]:
        for message_line in reversed(data["console"][-20:]):
            st.text(message_line)
    else:
        st.write("Nothing yet.")


st.warning(
    "Simulation only — not for clinical use or real patient monitoring."
)
