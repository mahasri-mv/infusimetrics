/*
  Smart IV Fluid Monitoring & Nurse Alert System
  PHASE 3: Phase 2 (GPS + on-device ML + NLP) + nurse call, DHT22, OLED, RGB LED, ultrasonic
  Board: Arduino MEGA 2560 (as in diagram.json)
  ----------------------------------------------------------------------
  ORIGINAL PARTS (unchanged behaviour):
    A0 fluid sensor (potentiometer) | 20/21 I2C LCD (SDA/SCL on the Mega) | 2 patient bulb
    4 SD CS | 6 servo clamp | 7 reset button | 8 buzzer | 9 red | 10 green
    50/51/52 SPI (SD card, fixed on the Mega)
    GPS (optional): GPS TX -> pin 3, GPS RX -> pin 5

  NEW PARTS (Phase 3):
    22  Nurse-call button (other leg to GND, internal pull-up)
    23  DHT22 data (temperature + humidity)
    24  RGB LED red   (via 220 ohm)   common cathode -> GND
    25  RGB LED green (via 220 ohm)
    26  RGB LED blue  (via 220 ohm)
    27  HC-SR04 TRIG
    28  HC-SR04 ECHO
    20/21 SSD1306 OLED 128x64 (I2C 0x3C, shares the bus with the LCD)

  NEW SERIAL LINES (existing DATA / EVENT lines are unchanged):
    ENV,temp_C,humidity_%
    DIST,distance_cm
    NURSE,1   (patient pressed call)      NURSE,0   (nurse acknowledged)
    NURSE,2   (call unanswered after NURSE_ESCALATE_MS -> escalated to backup staff)
    New EVENT names: NURSE_CALL, NURSE_ACK, NURSE_ESCALATED

  Nurse call is cleared by the reset button (pin 7) or by typing "ack" / "acknowledge".

  RGB colours: green = normal | amber = warning (early warn / leak / blockage)
               red = LOW or clamped | blue blinking = nurse call waiting
               fast red blinking = nurse call unanswered (escalated)

  Libraries to install:
    LiquidCrystal I2C, TinyGPSPlus, Servo, SD (already used)
    DHT sensor library + Adafruit Unified Sensor
    Adafruit SSD1306 + Adafruit GFX Library
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <SPI.h>
#include <SD.h>
#include <Servo.h>
#include <SoftwareSerial.h>
#include <TinyGPSPlus.h>
#include <avr/pgmspace.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

// ---------- Pin assignments (original) ----------
const int SENSOR_PIN    = A0;
const int BUZZER_PIN    = 8;
const int RED_LED_PIN   = 9;
const int GREEN_LED_PIN = 10;
const int BULB_PIN      = 2;
const int RESET_BTN_PIN = 7;
const int SD_CS_PIN     = 4;
const int SERVO_PIN     = 6;
const int GPS_RX_PIN    = 3;   // Arduino receives here  (GPS TX connects to pin 3)
const int GPS_TX_PIN    = 5;   // Arduino transmits here (GPS RX connects to pin 5)

// ---------- Pin assignments (new) ----------
const int NURSE_BTN_PIN = 22;
const int DHT_PIN       = 23;
const int RGB_R_PIN     = 24;
const int RGB_G_PIN     = 25;
const int RGB_B_PIN     = 26;
const int TRIG_PIN      = 27;
const int ECHO_PIN      = 28;

// ---------- Settings ----------
const int BED_ID = 1;                          // which bed this monitor serves

// Fallback location used when no live GPS fix exists (simulator has no GPS part)
const float FIXED_LAT = 11.7480;   // change to your hospital / college
const float FIXED_LON = 75.4920;

const int LOW_THRESHOLD = 20;                  // below this % = LOW
const int OK_THRESHOLD  = 25;                  // at/above this % = buzzer re-arms
const unsigned long CLAMP_DELAY_MS = 60000UL;  // 60 s unaddressed -> auto clamp
                                               // (use 20000UL while demonstrating)
const int SERVO_OPEN_ANGLE  = 90;
const int SERVO_CLAMP_ANGLE = 0;

// ML settings
const unsigned long ML_PERIOD_MS = 5000UL;     // one ML sample every 5 s
const int   WINDOW          = 12;              // regression window = 12 samples = 60 s
const float EARLY_WARN_MIN  = 2.0;             // warn if LOW will be reached within 2 min
                                               // (use ~5.0 on a real ward)
const float MIN_RATE        = 0.3;             // % per min needed before we predict
const float MIN_BASELINE    = 1.0;             // % per min needed to learn a "normal" rate
const float LEAK_FACTOR     = 2.5;             // leak if short-term rate > 2.5 x baseline
const float MIN_LEAK_RATE   = 3.0;             // ...and at least this fast (% per min)
const int   REFILL_JUMP     = 10;              // sudden rise >= 10 % = bottle was replaced

// Simulation (demo only)
const float SIM_DRAIN_STEP = 2.0;              // % lost per ML tick in "drain"
const float SIM_LEAK_STEP  = 7.0;              // % lost per ML tick in "leak"

// Extras (new)
const unsigned long EXTRAS_PERIOD_MS = 5000UL; // ENV + DIST lines every 5 s
const unsigned long OLED_PERIOD_MS   = 1000UL; // OLED refresh every 1 s
const unsigned long NURSE_ESCALATE_MS = 30000UL; // unanswered nurse call escalates after 30 s
                                                 // (use 15000UL while demonstrating)

const uint8_t SIM_OFF = 0, SIM_DRAIN = 1, SIM_LEAK = 2, SIM_BLOCK = 3;
const uint8_t ANOM_NONE = 0, ANOM_LEAK = 1, ANOM_BLOCK = 2;

// ---------- Objects ----------
LiquidCrystal_I2C lcd(0x27, 16, 2);            // try 0x3F if the screen stays blank
Servo clampServo;
SoftwareSerial gpsSerial(GPS_RX_PIN, GPS_TX_PIN);
TinyGPSPlus gps;
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
DHT dht(DHT_PIN, DHT22);

// ---------- State (original) ----------
bool alarmSilenced = false;
bool sdReady = false;
bool clamped = false;
unsigned long lowSince = 0;
unsigned long lastUpdate = 0;
const unsigned long UPDATE_INTERVAL = 500;

// ---------- State (Phase 2) ----------
int  currentLevel = 0;
bool currentLow = false;

uint8_t hist[WINDOW];          // last readings, oldest first
uint8_t histCount = 0;
unsigned long lastMl = 0;
float rateLong = 0;            // regression drain rate, % per minute
float rateShort = 0;           // drain rate over the last 3 samples
float baseline = 0;            // learned "normal" drain rate
float ttEmpty = -1;            // minutes until 0 %   (-1 = unknown)
float ttLow = -1;              // minutes until LOW threshold
uint8_t anomaly = ANOM_NONE;
uint8_t anomalyPrev = ANOM_NONE;
bool earlyWarned = false;
bool chirpNow = false;

uint8_t simMode = SIM_OFF;
float simLevel = 100;

char cmd[40];
byte cmdLen = 0;

// ---------- State (Phase 3) ----------
bool nurseCall = false;
bool nurseEscalated = false;
unsigned long nurseCallAt = 0;
bool oledReady = false;
float envTemp = 0, envHum = 0;
bool envValid = false;
float distCm = -1;
unsigned long lastExtras = 0;
unsigned long lastOled = 0;

// =====================================================================
// setup()
// =====================================================================
void setup() {
  Serial.begin(9600);
  gpsSerial.begin(9600);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(GREEN_LED_PIN, OUTPUT);
  pinMode(BULB_PIN, OUTPUT);
  pinMode(RESET_BTN_PIN, INPUT_PULLUP);

  // new pins
  pinMode(NURSE_BTN_PIN, INPUT_PULLUP);
  pinMode(RGB_R_PIN, OUTPUT);
  pinMode(RGB_G_PIN, OUTPUT);
  pinMode(RGB_B_PIN, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  digitalWrite(TRIG_PIN, LOW);
  dht.begin();

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print(F("IV Fluid Monitor"));
  lcd.setCursor(0, 1);
  lcd.print(F("Initializing... "));

  oledReady = oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  if (oledReady) {
    Wire.setClock(400000);
    oled.clearDisplay();
    oled.setTextSize(1);
    oled.setTextColor(SSD1306_WHITE);
    oled.setCursor(0, 0);
    oled.println(F("IV Fluid Monitor"));
    oled.println(F("Initializing..."));
    oled.display();
  } else {
    Serial.println(F("OLED not found - continuing without it."));
  }

  pinMode(53, OUTPUT);
  sdReady = SD.begin(SD_CS_PIN);
  if (sdReady) {
    ensureHeader("ivlog.csv",  F("elapsed_ms,level,event,rate,lat,lon"));
    ensureHeader("ivdata.csv", F("elapsed_ms,level"));
    Serial.println(F("SD card ready."));
  } else {
    Serial.println(F("SD card not found - logging disabled, rest of system still works."));
  }

  clampServo.attach(SERVO_PIN);
  clampServo.write(SERVO_OPEN_ANGLE);

  delay(1200);
  lcd.clear();

  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(GREEN_LED_PIN, LOW);
  digitalWrite(BULB_PIN, LOW);
  noTone(BUZZER_PIN);

  Serial.println(F("Type 'help' for commands."));
}

// =====================================================================
// Helpers: SD header, GPS, logging, alerts
// =====================================================================
void ensureHeader(const char *name, const __FlashStringHelper *header) {
  if (SD.exists(name)) return;                // write the header only once
  File f = SD.open(name, FILE_WRITE);
  if (f) {
    f.println(header);
    f.close();
  }
}

void feedGPS() {
  while (gpsSerial.available()) gps.encode(gpsSerial.read());
}

void printLocation() {
  if (gps.location.isValid()) {
    Serial.print(gps.location.lat(), 5);
    Serial.print(F(", "));
    Serial.print(gps.location.lng(), 5);
  } else {
    Serial.print(FIXED_LAT, 5);
    Serial.print(F(", "));
    Serial.print(FIXED_LON, 5);
    Serial.print(F(" (fixed bed location)"));
  }
}

// Writes one event line to any output (the SD file or the Serial Monitor)
void writeEventCSV(Print &out, int level, const __FlashStringHelper *ev) {
  out.print(millis());
  out.print(',');
  out.print(level);
  out.print(',');
  out.print(ev);
  out.print(',');
  out.print(rateLong, 2);
  out.print(',');
  if (gps.location.isValid()) {
    out.print(gps.location.lat(), 6);
    out.print(',');
    out.print(gps.location.lng(), 6);
  } else {
    out.print(FIXED_LAT, 6);
    out.print(',');
    out.print(FIXED_LON, 6);
  }
  out.println();
}

void logEvent(int level, const __FlashStringHelper *ev) {
  Serial.print(F("EVENT,"));
  writeEventCSV(Serial, level, ev);
  if (!sdReady) return;
  File f = SD.open("ivlog.csv", FILE_WRITE);
  if (!f) return;
  writeEventCSV(f, level, ev);
  f.close();
}

void logSample(int level) {
  Serial.print(F("DATA,"));
  Serial.print(millis());
  Serial.print(',');
  Serial.println(level);
  if (!sdReady) return;
  File f = SD.open("ivdata.csv", FILE_WRITE);
  if (!f) return;
  f.print(millis());
  f.print(',');
  f.println(level);
  f.close();
}

// Readable alert sentence (the "NLP generation" part)
void sendAlert(const __FlashStringHelper *what, int level) {
  Serial.print(F("ALERT Bed "));
  Serial.print(BED_ID);
  Serial.print(F(": "));
  Serial.print(what);
  Serial.print(F(" | Level "));
  Serial.print(level);
  Serial.print(F("%"));
  if (ttEmpty >= 0) {
    Serial.print(F(" | about "));
    Serial.print(ttEmpty, 1);
    Serial.print(F(" min to empty"));
  }
  Serial.print(F(" | Location "));
  printLocation();
  Serial.println();
}

// =====================================================================
// Sensor: average 8 readings, convert to 0-100 %
// =====================================================================
int readFluidLevelPercent() {
  const int SAMPLES = 8;
  long total = 0;
  for (int i = 0; i < SAMPLES; i++) {
    total += analogRead(SENSOR_PIN);
    delay(2);
  }
  int raw = total / SAMPLES;
  return map(raw, 0, 1023, 0, 100);
}

// Real sensor normally; simulated level when a demo simulation is running
int readLevel() {
  if (simMode == SIM_OFF) return readFluidLevelPercent();
  return (int)simLevel;
}

void stepSimulation() {
  if (simMode == SIM_OFF || clamped) return;   // a clamped line stops draining
  if (simMode == SIM_DRAIN) simLevel -= SIM_DRAIN_STEP;
  else if (simMode == SIM_LEAK) simLevel -= SIM_LEAK_STEP;
  if (simLevel < 0) simLevel = 0;
}

// =====================================================================
// NEW: nurse call, DHT22, ultrasonic, RGB LED, OLED
// =====================================================================

// Patient presses the nurse-call button (debounced). Stays active until acknowledged.
void handleNurseButton() {
  static bool lastRaw = HIGH;
  static bool stable = HIGH;
  static unsigned long changedAt = 0;

  bool raw = digitalRead(NURSE_BTN_PIN);
  if (raw != lastRaw) {
    lastRaw = raw;
    changedAt = millis();
  }
  if ((millis() - changedAt) >= 40 && raw != stable) {
    stable = raw;
    if (stable == LOW && !nurseCall) {
      nurseCall = true;
      nurseCallAt = millis();
      nurseEscalated = false;
      logEvent(currentLevel, F("NURSE_CALL"));
      Serial.println(F("NURSE,1"));
      sendAlert(F("patient pressed the NURSE CALL button"), currentLevel);
    }
  }
}

void clearNurseCall() {
  if (!nurseCall) return;
  nurseCall = false;
  nurseEscalated = false;
  logEvent(currentLevel, F("NURSE_ACK"));
  Serial.println(F("NURSE,0"));
  Serial.println(F("Nurse call acknowledged."));
}

// If nobody answers the nurse call in time, escalate to backup staff
void checkNurseEscalation() {
  if (!nurseCall || nurseEscalated) return;
  if (millis() - nurseCallAt >= NURSE_ESCALATE_MS) {
    nurseEscalated = true;
    logEvent(currentLevel, F("NURSE_ESCALATED"));
    Serial.println(F("NURSE,2"));
    sendAlert(F("nurse call UNANSWERED - escalating to backup staff"), currentLevel);
  }
}

// HC-SR04 distance in cm, -1 if no echo
float readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  unsigned long d = pulseIn(ECHO_PIN, HIGH, 30000UL);
  if (d == 0) return -1;
  return d * 0.0343 / 2.0;
}

// Reads DHT22 + ultrasonic and prints ENV / DIST lines for the dashboard
void readExtras() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  if (!isnan(t) && !isnan(h)) {
    envTemp = t;
    envHum = h;
    envValid = true;
    Serial.print(F("ENV,"));
    Serial.print(t, 1);
    Serial.print(',');
    Serial.println(h, 1);
  }

  float d = readDistanceCm();
  if (d >= 0) {
    distCm = d;
    Serial.print(F("DIST,"));
    Serial.println(d, 1);
  }
}

// RGB status light: runs on every loop pass so the blink is smooth
void updateRGB() {
  bool r = false, g = false, b = false;
  if (clamped || currentLow) {
    r = true;                                          // critical
  } else if (nurseCall) {
    if (nurseEscalated) r = ((millis() / 200) % 2 == 0);   // fast red blink = unanswered
    else b = ((millis() / 400) % 2 == 0);                  // slow blue blink = waiting
  } else if (anomaly != ANOM_NONE || (ttLow >= 0 && ttLow < EARLY_WARN_MIN)) {
    r = true; g = true;                                // amber warning
  } else {
    g = true;                                          // normal
  }
  digitalWrite(RGB_R_PIN, r ? HIGH : LOW);
  digitalWrite(RGB_G_PIN, g ? HIGH : LOW);
  digitalWrite(RGB_B_PIN, b ? HIGH : LOW);
}

void showOLED() {
  if (!oledReady) return;
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setTextColor(SSD1306_WHITE);
  oled.setCursor(0, 0);
  oled.print(F("IV Monitor  Bed "));
  oled.println(BED_ID);

  oled.print(F("Level: "));
  oled.print(currentLevel);
  oled.println(F("%"));

  oled.print(F("Rate: "));
  oled.print(rateLong > 0 ? rateLong : 0, 1);
  oled.println(F(" %/min"));

  oled.print(F("Status: "));
  if (clamped) oled.println(F("CLAMPED"));
  else if (currentLow) oled.println(F("LOW"));
  else if (anomaly == ANOM_LEAK) oled.println(F("LEAK?"));
  else if (anomaly == ANOM_BLOCK) oled.println(F("BLOCKED?"));
  else oled.println(F("NORMAL"));

  if (envValid) {
    oled.print(F("T:"));
    oled.print(envTemp, 1);
    oled.print(F("C H:"));
    oled.print(envHum, 0);
    oled.println(F("%"));
  } else {
    oled.println(F("T: --"));
  }

  if (distCm >= 0) {
    oled.print(F("Dist: "));
    oled.print(distCm, 0);
    oled.println(F(" cm"));
  } else {
    oled.println(F("Dist: --"));
  }

  if (nurseCall) oled.println(nurseEscalated ? F("NO RESPONSE!") : F("** NURSE CALL **"));
  oled.display();
}

// =====================================================================
// ML: online linear regression + anomaly detection
// =====================================================================
void resetML() {
  histCount = 0;
  rateLong = 0;
  rateShort = 0;
  baseline = 0;
  ttEmpty = -1;
  ttLow = -1;
  anomaly = ANOM_NONE;
  anomalyPrev = ANOM_NONE;
  earlyWarned = false;
}

// Least-squares slope of level vs sample index, converted to % per minute
float computeDrainRate() {
  if (histCount < 4) return 0;
  int n = histCount;
  float sx = 0, sy = 0, sxy = 0, sxx = 0;
  for (int i = 0; i < n; i++) {
    float x = i;
    float y = hist[i];
    sx += x;
    sy += y;
    sxy += x * y;
    sxx += x * x;
  }
  float den = n * sxx - sx * sx;
  if (den == 0) return 0;
  float slope = (n * sxy - sx * sy) / den;     // % per sample
  return -slope * (60000.0 / ML_PERIOD_MS);    // % per minute (positive = draining)
}

// Quick rate from the last 3 samples (reacts faster than the full window)
float computeShortRate() {
  if (histCount < 3) return 0;
  float drop = (float)hist[histCount - 3] - (float)hist[histCount - 1];
  return (drop / 2.0) * (60000.0 / ML_PERIOD_MS);
}

void mlUpdate(int level) {
  // A big sudden rise means the bottle was replaced: restart the window
  // but keep the learned baseline rate.
  if (histCount > 0 && level >= hist[histCount - 1] + REFILL_JUMP) {
    float b = baseline;
    resetML();
    baseline = b;
  }

  // Add the new reading to the window (oldest drops out when full)
  if (histCount < WINDOW) {
    hist[histCount++] = level;
  } else {
    for (int i = 0; i < WINDOW - 1; i++) hist[i] = hist[i + 1];
    hist[WINDOW - 1] = level;
  }

  rateLong = computeDrainRate();
  rateShort = computeShortRate();

  // ---- Anomaly detection against the learned baseline ----
  anomalyPrev = anomaly;
  anomaly = ANOM_NONE;
  if (!clamped && histCount >= WINDOW) {
    if (baseline <= 0) {
      if (rateLong > MIN_BASELINE) baseline = rateLong;   // learn "normal"
    } else {
      if (rateShort > LEAK_FACTOR * baseline && rateShort > MIN_LEAK_RATE) {
        anomaly = ANOM_LEAK;
      } else if (rateShort < 0.1 * baseline && level > 5) {
        anomaly = ANOM_BLOCK;
      } else if (rateLong > 0.5 * baseline && rateLong < 2.0 * baseline) {
        baseline = 0.9 * baseline + 0.1 * rateLong;       // slowly adapt
      }
    }
  }

  // ---- Prediction ----
  ttEmpty = -1;
  ttLow = -1;
  if (histCount >= 4 && rateLong > MIN_RATE) {
    ttEmpty = level / rateLong;
    ttLow = (level - LOW_THRESHOLD) / rateLong;
    if (ttLow < 0) ttLow = 0;
    if (ttEmpty > 99.9) ttEmpty = 99.9;
  }

  // ---- Alerts from ML ----
  if (anomaly != ANOM_NONE && anomaly != anomalyPrev) {
    if (anomaly == ANOM_LEAK) {
      logEvent(level, F("LEAK_SUSPECTED"));
      sendAlert(F("possible LEAK - fluid dropping unusually fast"), level);
    } else {
      logEvent(level, F("BLOCK_SUSPECTED"));
      sendAlert(F("possible BLOCKAGE - flow has stopped"), level);
    }
  }

  if (ttLow < 0 || ttLow > EARLY_WARN_MIN * 1.5) earlyWarned = false;
  if (!earlyWarned && ttLow >= 0 && ttLow < EARLY_WARN_MIN && level >= LOW_THRESHOLD) {
    earlyWarned = true;
    chirpNow = true;
    logEvent(level, F("EARLY_WARN"));
    sendAlert(F("bottle will run low soon (early warning)"), level);
  }
}

// =====================================================================
// LCD
// =====================================================================
void showStatus(int level, bool low) {
  char buf[8];
  char line[17];

  float r = (rateLong > 0) ? rateLong : 0;
  dtostrf(r, 4, 1, buf);
  snprintf(line, sizeof(line), "L:%d%% %s%%/min   ", level, buf);
  lcd.setCursor(0, 0);
  lcd.print(line);

  lcd.setCursor(0, 1);
  if (clamped) {
    lcd.print(F("Auto-clamped!   "));
  } else if (low && alarmSilenced) {
    lcd.print(F("Refill! (muted) "));
  } else if (low) {
    lcd.print(F("Refill Needed!  "));
  } else if (nurseCall) {
    lcd.print(nurseEscalated ? F("NO RESPONSE!    ") : F("NURSE CALLED!   "));
  } else if (anomaly == ANOM_LEAK) {
    lcd.print(F("LEAK suspected! "));
  } else if (anomaly == ANOM_BLOCK) {
    lcd.print(F("Flow blocked?   "));
  } else if (ttEmpty >= 0) {
    dtostrf(ttEmpty, 3, 1, buf);
    snprintf(line, sizeof(line), "Empty ~%s min   ", buf);
    lcd.print(line);
  } else {
    lcd.print(F("Level: OK       "));
  }
}

// =====================================================================
// Reset button: silences the buzzer and acknowledges a nurse call
// =====================================================================
void handleReset() {
  if (digitalRead(RESET_BTN_PIN) == LOW) {
    if (!alarmSilenced) Serial.println(F("Nurse reset pressed - buzzer silenced."));
    alarmSilenced = true;
    clearNurseCall();
  }
}

// =====================================================================
// NLP: read a line from the Serial Monitor and work out what it means
// =====================================================================
#define HAS(word) (strstr_P(cmd, PSTR(word)) != NULL)

// Entity extraction: number written right after a keyword ("bed 4" -> 4)
int extractNumberAfter(const char *keyword_P) {
  const char *p = strstr_P(cmd, keyword_P);
  if (!p) return -1;
  p += strlen_P(keyword_P);
  while (*p == ' ') p++;
  if (!isdigit(*p)) return -1;
  return atoi(p);
}

void setSimMode(uint8_t m) {
  if (m == SIM_OFF) {
    simMode = SIM_OFF;
    resetML();
    return;
  }
  if (simMode == SIM_OFF) {          // starting a simulation from the real sensor
    simLevel = currentLevel;
    resetML();
  }
  simMode = m;                       // switching drain/leak/block keeps what ML learned
}

void printHelp() {
  Serial.println(F("Commands (plain English is fine):"));
  Serial.println(F("  status / what is the level"));
  Serial.println(F("  how long is left / when will it be empty"));
  Serial.println(F("  where is the patient / location"));
  Serial.println(F("  silence alarm"));
  Serial.println(F("  is the clamp on"));
  Serial.println(F("  temperature / humidity / distance"));
  Serial.println(F("  ack  (acknowledge the nurse call)"));
  Serial.println(F("  add 'bed N' to address a bed, e.g. status of bed 1"));
  Serial.println(F("Demo: simulate drain | simulate leak | simulate block | simulate off | refill"));
}

void processCommand() {
  Serial.print(F("> "));
  Serial.println(cmd);

  // Entity: which bed is the nurse asking about?
  int bed = extractNumberAfter(PSTR("bed"));
  if (bed < 0) bed = extractNumberAfter(PSTR("room"));
  if (bed >= 0 && bed != BED_ID) {
    Serial.print(F("This monitor serves Bed "));
    Serial.print(BED_ID);
    Serial.println(F(" only."));
    return;
  }

  // Intent: acknowledge the nurse call
  if (strcmp_P(cmd, PSTR("ack")) == 0 || HAS("acknowledge") || HAS("answer")) {
    if (nurseCall) clearNurseCall();
    else Serial.println(F("There is no active nurse call."));
  }
  // Intent: environment readings
  else if (HAS("temp") || HAS("humid") || HAS("weather")) {
    if (envValid) {
      Serial.print(F("Room temperature "));
      Serial.print(envTemp, 1);
      Serial.print(F(" C, humidity "));
      Serial.print(envHum, 0);
      Serial.println(F(" %."));
    } else {
      Serial.println(F("No temperature reading yet."));
    }
  }
  // Intent: ultrasonic distance
  else if (HAS("distance") || HAS("ultrasonic")) {
    if (distCm >= 0) {
      Serial.print(F("Ultrasonic distance: "));
      Serial.print(distCm, 1);
      Serial.println(F(" cm."));
    } else {
      Serial.println(F("No distance reading yet."));
    }
  }
  // Intent: demo simulation
  else if (HAS("simulat") || HAS("demo")) {
    uint8_t m = SIM_DRAIN;
    if (HAS("leak")) m = SIM_LEAK;
    else if (HAS("block")) m = SIM_BLOCK;
    else if (HAS("off") || HAS("stop") || HAS("normal")) m = SIM_OFF;
    setSimMode(m);
    if (m == SIM_OFF) Serial.println(F("Simulation off - using the real sensor."));
    else if (m == SIM_DRAIN) Serial.println(F("Simulating normal drain."));
    else if (m == SIM_LEAK) Serial.println(F("Simulating a LEAK (fast drop)."));
    else Serial.println(F("Simulating a BLOCKAGE (level frozen)."));
  }
  // Intent: refill (demo)
  else if (HAS("refill") || HAS("replace") || HAS("new bottle")) {
    if (simMode == SIM_OFF) {
      Serial.println(F("Real sensor mode: turn the knob above 25% to refill."));
    } else {
      simLevel = 100;
      simMode = SIM_DRAIN;
      Serial.println(F("Bottle replaced: level set to 100%."));
    }
  }
  // Intent: silence the alarm
  else if (HAS("silence") || HAS("mute") || HAS("quiet") || (HAS("stop") && HAS("alarm"))) {
    if (currentLow) {
      alarmSilenced = true;
      Serial.println(F("Buzzer silenced. Red LED and bulb stay on until the bottle is refilled."));
    } else {
      Serial.println(F("There is no active alarm."));
    }
  }
  // Intent: location
  else if (HAS("where") || HAS("location") || HAS("gps") || HAS("position")) {
    Serial.print(F("Patient location: "));
    printLocation();
    Serial.println();
  }
  // Intent: time remaining (ML prediction)
  else if (HAS("how long") || HAS("time") || HAS("left") || HAS("remain") ||
           HAS("empty") || HAS("predict") || HAS("when")) {
    if (ttEmpty >= 0) {
      Serial.print(F("Estimated "));
      Serial.print(ttEmpty, 1);
      Serial.print(F(" min until empty, "));
      Serial.print(ttLow, 1);
      Serial.println(F(" min until the LOW alarm."));
    } else if (histCount < 4) {
      Serial.println(F("Still collecting data - ask again in about 20 seconds."));
    } else {
      Serial.println(F("The bottle is not draining, so there is nothing to predict."));
    }
  }
  // Intent: clamp state
  else if (HAS("clamp")) {
    Serial.println(clamped ? F("The IV line is CLAMPED.") : F("The clamp is open."));
  }
  // Intent: status
  else if (HAS("status") || HAS("level") || HAS("how much") || HAS("fluid") || HAS("bottle")) {
    Serial.print(F("Bed "));
    Serial.print(BED_ID);
    Serial.print(F(": level "));
    Serial.print(currentLevel);
    Serial.print(F("%, drain rate "));
    Serial.print(rateLong > 0 ? rateLong : 0, 1);
    Serial.print(F(" %/min, "));
    if (clamped) Serial.println(F("AUTO-CLAMPED."));
    else if (currentLow) Serial.println(F("LOW - refill needed."));
    else if (anomaly == ANOM_LEAK) Serial.println(F("possible LEAK."));
    else if (anomaly == ANOM_BLOCK) Serial.println(F("possible BLOCKAGE."));
    else Serial.println(F("OK."));
    if (nurseCall) Serial.println(F("A nurse call is waiting."));
  }
  else if (HAS("help")) {
    printHelp();
  }
  else {
    Serial.println(F("Sorry, I did not understand. Type 'help'."));
  }
}

void handleSerialInput() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (cmdLen > 0) {
        cmd[cmdLen] = 0;
        processCommand();
        cmdLen = 0;
      }
    } else if (cmdLen < sizeof(cmd) - 1) {
      cmd[cmdLen++] = tolower(c);
    }
  }
}

// =====================================================================
// loop()
// =====================================================================
void loop() {
  handleReset();          // checked on every pass so a press is never missed
  handleNurseButton();    // patient nurse-call button
  checkNurseEscalation(); // unanswered call -> escalate
  handleSerialInput();    // nurse text commands
  feedGPS();              // keep the GPS parser fed
  updateRGB();            // status colour (smooth blink needs every pass)

  if (millis() - lastExtras >= EXTRAS_PERIOD_MS) {
    lastExtras = millis();
    readExtras();         // ENV + DIST lines
  }

  if (millis() - lastOled >= OLED_PERIOD_MS) {
    lastOled = millis();
    showOLED();
  }

  if (millis() - lastUpdate >= UPDATE_INTERVAL) {
    lastUpdate = millis();

    bool mlTick = (millis() - lastMl >= ML_PERIOD_MS);
    if (mlTick) {
      lastMl = millis();
      stepSimulation();
    }

    int level = readLevel();
    currentLevel = level;
    bool wasLow = (lowSince != 0);
    bool low = level < LOW_THRESHOLD;
    currentLow = low;

    // Level JUST went low -> remember the time, log it, alert
    if (low && !wasLow) {
      lowSince = millis();
      logEvent(level, F("LOW"));
      sendAlert(F("IV bottle is LOW - refill needed"), level);
    }

    // Level JUST recovered -> reset timer, release clamp, log
    if (!low && wasLow) {
      lowSince = 0;
      if (clamped) {
        clamped = false;
        clampServo.write(SERVO_OPEN_ANGLE);
      }
      logEvent(level, F("REFILLED"));
      sendAlert(F("bottle refilled - flow restored"), level);
    }

    // Still low after 60 s with nobody responding -> auto-clamp
    if (low && !clamped && lowSince != 0 && (millis() - lowSince) >= CLAMP_DELAY_MS) {
      clamped = true;
      clampServo.write(SERVO_CLAMP_ANGLE);
      logEvent(level, F("AUTO_CLAMPED"));
      sendAlert(F("auto-clamp engaged - line closed"), level);
    }

    // Level clearly recovered -> re-arm the buzzer
    if (level >= OK_THRESHOLD) {
      alarmSilenced = false;
    }

    // ML runs once every 5 s
    if (mlTick) {
      mlUpdate(level);
      logSample(level);
    }

    showStatus(level, low);

    // LEDs and bulb always show the TRUE state
    digitalWrite(RED_LED_PIN,   low ? HIGH : LOW);
    digitalWrite(GREEN_LED_PIN, low ? LOW  : HIGH);
    digitalWrite(BULB_PIN,      low ? HIGH : LOW);

    // Buzzer: fast high beep when clamped, slow beep when low,
    // short ding while a nurse call waits, else silent
    bool buzzerRinging = low && !alarmSilenced && !clamped;
    if (clamped) {
      tone(BUZZER_PIN, 2000, 150);
    } else if (buzzerRinging) {
      tone(BUZZER_PIN, 1000, 400);
    } else if (nurseCall) {
      if (nurseEscalated) tone(BUZZER_PIN, 2500, 300);   // louder, longer = unanswered
      else tone(BUZZER_PIN, 1800, 100);
    } else {
      noTone(BUZZER_PIN);
    }
    if (chirpNow) {                  // short chirp for the ML early warning
      tone(BUZZER_PIN, 1500, 100);
      chirpNow = false;
    }

    // Debug line, once per ML tick so the Serial Monitor stays readable
    if (mlTick) {
      Serial.print(F("STATUS | Level: "));
      Serial.print(level);
      Serial.print(F("% | Rate: "));
      Serial.print(rateLong, 1);
      Serial.print(F(" %/min | Low: "));
      Serial.print(low ? F("YES") : F("NO"));
      Serial.print(F(" | Clamped: "));
      Serial.print(clamped ? F("YES") : F("NO"));
      Serial.print(F(" | Sim: "));
      Serial.println(simMode);
    }
  }
}
