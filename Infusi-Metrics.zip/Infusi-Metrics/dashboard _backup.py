
import streamlit as st
import serial
import threading
import time
from smart_features import predict_next_level, answer_question
import pandas as pd
from streamlit_autorefresh import st_autorefresh

PORT = "rfc2217://localhost:4000"
BAUD_RATE = 115200

st.set_page_config(
    page_title="IV Fluid Monitor",
    page_icon="💧",
    layout="wide",
    initial_sidebar_state="expanded",
)
st.markdown("""
<style>
    .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        max-width: 1400px;
    }

    div[data-testid="stMetric"] {
        background: #172536;
        border: 1px solid #29445c;
        padding: 18px;
        border-radius: 14px;
    }

    div[data-testid="stMetricLabel"] {
        color: #b8cce0;
    }

    h1, h2, h3 {
        letter-spacing: -0.4px;
    }
</style>
""", unsafe_allow_html=True)
# Shared data between the serial reader and dashboard.
if "iv_data" not in st.session_state:
    st.session_state.iv_data = {
        "level": None,
        "rate": 0.0,
        "low": False,
        "clamped": False,
        "status": "Waiting for data",
        "history": [],
        "events": [],
    }

if "reader_started" not in st.session_state:
    st.session_state.reader_started = False


def read_serial():
    try:
        with serial.serial_for_url(
            PORT, baudrate=BAUD_RATE, timeout=2
        ) as connection:
            while True:
                raw = connection.readline()
                if not raw:
                    continue

                line = raw.decode(
                    "utf-8", errors="replace"
                ).strip()
                parts = line.split(",")

                if len(parts) == 3 and parts[0] == "DATA":
                    try:
                        elapsed = int(parts[1]) / 1000
                        level = int(parts[2])

                        with data_lock:
                            shared_data["level"] = level
                            shared_data["history"].append({
                                "Time (s)": elapsed,
                                "Level (%)": level,
                            })
                            shared_data["history"] = (
                                shared_data["history"][-100:]
                            )
                    except ValueError:
                        pass

                elif line.startswith("STATUS"):
                    with data_lock:
                        shared_data["status"] = line
                        shared_data["low"] = "Low: YES" in line
                        shared_data["clamped"] = (
                            "Clamped: YES" in line
                        )

                elif line.startswith("EVENT,"):
                    with data_lock:
                        shared_data["events"].append(line)
                        shared_data["events"] = (
                            shared_data["events"][-20:]
                        )

    except Exception as error:
        with data_lock:
            shared_data["status"] = f"Serial error: {error}"


# Keep the data outside Streamlit's rerun-specific session state.
# This is for one local dashboard process.
if "shared_setup" not in st.session_state:
    data_lock = threading.Lock()
    shared_data = {
        "level": None,
        "rate": 0.0,
        "low": False,
        "clamped": False,
        "status": "Connecting to Wokwi...",
        "history": [],
        "events": [],
    }
    st.session_state.shared_setup = True
    st.session_state.data_lock = data_lock
    st.session_state.shared_data = shared_data
    reader = threading.Thread(target=read_serial, daemon=True)
    reader.start()

# Restore references on each Streamlit rerun.
data_lock = st.session_state.data_lock
shared_data = st.session_state.shared_data

st_autorefresh(interval=2000, key="iv_refresh")

with data_lock:
    data = {
        **shared_data,
        "history": list(shared_data["history"]),
        "events": list(shared_data["events"]),
    }

st.title("💧 IV Fluid Monitoring Dashboard")
st.caption("Live readings from the Wokwi Arduino simulation")

a, b, c, d = st.columns(4)
a.metric(
    "IV Fluid Level",
    f"{data['level']}%" if data["level"] is not None else "--",
)
b.metric("Flow Rate", f"{data['rate']:.1f} %/min")
c.metric("Low Alert", "YES" if data["low"] else "NO")
d.metric("Clamped", "YES" if data["clamped"] else "NO")


st.subheader("🤖 ML: Next IV Level Estimate")

if len(data["history"]) >= 5:
    levels = [item["Level (%)"] for item in data["history"]]
    prediction, message = predict_next_level(levels)

    if prediction is not None:
        st.metric("Estimated Next Level", f"{prediction:.1f}%")
        st.caption(message)
    else:
        st.info(message)
else:
    st.info("Collect at least 5 readings to enable the ML estimate.")


st.subheader("💬 Ask About Your IV Simulation")

question = st.text_input(
    "Ask a question",
    placeholder="e.g. What is the current level? Is the IV low?",
    key="iv_question",
)

if question:
    answer = answer_question(
        question,
        data["level"],
        data["status"],
        data["events"],
    )
    st.info(answer)

st.subheader("Arduino Status")
st.write(data["status"])

st.subheader("IV Level History")
if data["history"]:
    st.line_chart(data["history"], x="Time (s)", y="Level (%)")
else:
    st.info("Waiting for readings from Wokwi...")

st.subheader("Recent Events")
if data["events"]:
    for event in reversed(data["events"]):
        st.text(event)
else:
    st.write("No events received yet.")

st.warning(
    "Simulation only — not for clinical use or real patient monitoring."
)
